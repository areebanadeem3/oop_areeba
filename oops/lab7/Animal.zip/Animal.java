/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.animal;

/**
 *
 * @author f23ari84
 */
public class Animal {
    String name;
    int age;
    
    Animal(String n, int a) {
        name=n;
        age=a;
    }

    public static void main(String[] args) {
        dog d = new dog("tommy , 4");
        cat c = new cat("kitty , 6");  
        
        d.show();
        c.show();
        System.out.println("Hello World!");
    }
}
