/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab007;

/**
 *
 * @author DELL
 */
public class Lab007 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
     Sms sms = new Sms();
        sms.setRecipientContactNo("03001234567");
        sms.setText("Hello via SMS");

        Email email = new Email();
        email.setSender("john@example.com");
        email.setReceiver("doe@example.com");
        email.setSubject("Meeting");
        email.setText("Let's meet at 5 PM");

        System.out.println(sms);
        System.out.println(email);

        System.out.println("SMS contains 'SMS'? " + containsKeyword(sms, "SMS"));
        System.out.println("Email contains 'meet'? " + containsKeyword(email, "meet"));
    }

    public static boolean containsKeyword(Message m, String keyword) {
        return m.text.contains(keyword);
    }
}

        // TODO code application logic here
    }
    

