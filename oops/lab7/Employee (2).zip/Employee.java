/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.employee;

/**
 *
 * @author f23ari84
 */
public class Employee {
    public int calculatesalary(){
        return 1000;
    }

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
