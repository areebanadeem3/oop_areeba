/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vowelconsonantcount;

/**
 *
 * @author DELL
 */
public class VowelConsonantCount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String input = "Hello World!";
        int vowels = 0;
        int consonants = 0;

        // Convert to lowercase to simplify checking
        input = input.toLowerCase();

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (Character.isLetter(ch)) {
                if ("aeiou".indexOf(ch) != -1) {
                    vowels++;
                } else {
                    consonants++;
                }
            }
        }

        System.out.println("Input: " + input);
        System.out.println("Vowels: " + vowels);
        System.out.println("Consonants: " + consonants);
    }
}
        // TODO code application logic here
    }
    
}
