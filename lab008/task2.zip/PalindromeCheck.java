/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package palindromecheck;

/**
 *
 * @author DELL
 */
public class PalindromeCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String input = "A man, a plan, a canal: Panama";
        int left = 0;
        int right = input.length() - 1;
        boolean isPalindrome = true;

        while (left < right) {
            // Skip non-alphanumeric characters
            while (left < right && !Character.isLetterOrDigit(input.charAt(left))) {
                left++;
            }
            while (left < right && !Character.isLetterOrDigit(input.charAt(right))) {
                right--;
            }

            // Compare characters (case-insensitive)
            if (Character.toLowerCase(input.charAt(left)) != Character.toLowerCase(input.charAt(right))) {
                isPalindrome = false;
                break;
            }

            left++;
            right--;
        }

        System.out.println("Is Palindrome: " + isPalindrome);
 
    }}
