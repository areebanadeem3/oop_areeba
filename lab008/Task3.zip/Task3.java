/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task3;

import java.util.Set;

/**
 *
 * @author DELL
 */
public class Task3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // TODO code application logic here
    }public static int longestUniqueSubstring(String str) {
        Set<Character> set = new HashSet<>();
        int maxLen = 0, i = 0, j = 0;
        while (j < str.length()) {
            if (!set.contains(str.charAt(j))) {
                set.add(str.charAt(j++));
                maxLen = Math.max(maxLen, set.size());
            } else {
                set.remove(str.charAt(i++));
            }
        }
        return maxLen;
    }

    
}
