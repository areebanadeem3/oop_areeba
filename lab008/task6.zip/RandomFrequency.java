/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package randomfrequency;

/**
 *
 * @author DELL
 */
 import java.util.Random;

public class RandomFrequency {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int[] freq = new int[21]; // index 0 to 20
        Random rand = new Random();

        // Generate 100 random numbers and count frequency
        for (int i = 0; i < 100; i++) {
            int num = rand.nextInt(21); // 0 to 20
            freq[num]++;
        }

        // Print frequencies
        for (int i = 0; i < freq.length; i++) {
            System.out.println("Number " + i + ": " + freq[i] + " times");
        }
    }
}
        // TODO code application logic here
    }
    
}
