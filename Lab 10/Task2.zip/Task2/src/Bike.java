public class Bike implements Vehicle{
    public void Start(){
        System.out.println("Bike Starts");

    }
    public void Stop(){
        System.out.println("Bike stops");
    }
}
