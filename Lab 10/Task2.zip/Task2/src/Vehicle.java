 interface Vehicle {

    void Start();

    void Stop();

}
