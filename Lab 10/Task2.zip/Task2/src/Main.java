class Main {
    public static void main(String[] args) {
        Car c= new Car();
        c.Start();
        c.Stop();

        Bike b = new Bike();
        b.Start();
        b.Stop();

    }
}
