class Car implements Vehicle{
    @Override
    public void Stop() {
        System.out.println(" ");
    }

    public void Start(){
        System.out.println("Car Starts");

        }
    }

