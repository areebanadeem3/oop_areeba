class Cat extends Animal {
        @Override
        void makeSound() {
            System.out.println("Meow");
}}
