abstract class Shape {
    abstract double area(); }

interface Printable {
    void print(); }



