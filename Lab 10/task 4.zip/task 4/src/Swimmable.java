interface Swimmable {
    void swim(); //
}
