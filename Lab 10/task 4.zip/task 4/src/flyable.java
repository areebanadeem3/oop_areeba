interface flyable {
    void fly(); // M
}
