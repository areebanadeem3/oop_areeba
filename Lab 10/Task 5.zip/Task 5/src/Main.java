public class Main {
    public static void main(String[] args) {
        PartTimeEmployee fullTimeEmployee = new PartTimeEmployee("Alice", 2, 1, 3000);
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Bob", 2, 20, 100);

                System.out.println("Full-Time Employee Salary: " + fullTimeEmployee.calculateSalary());
                fullTimeEmployee.payTax();

                System.out.println("Part-Time Employee Salary: " + partTimeEmployee.calculateSalary());
                partTimeEmployee.payTax();
            }
        }

