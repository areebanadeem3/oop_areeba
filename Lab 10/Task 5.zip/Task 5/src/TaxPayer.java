  interface  TaxPayer {
        void payTax();
}
