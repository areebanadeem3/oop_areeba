public class PartTimeEmployee extends Employee implements TaxPayer{
    private double monthlySalary;

        PartTimeEmployee(String name, int i, int id, double monthlySalary) {
            super(name, id);
            this.monthlySalary = monthlySalary;
        }

        double calculateSalary() {
            return monthlySalary; // Fixed monthly salary
        }

        public void payTax() {
            System.out.println(name + " pays tax on a salary of " + calculateSalary());
        }
    }


