 class PartTimeEmpolyee extends Employee implements TaxPayer {

        private double hourlyRate;
        private int hoursWorked;

        PartTimeEmpolyee(String name, int id, double hourlyRate, int hoursWorked) {
            super(name, id);
            this.hourlyRate = hourlyRate;
            this.hoursWorked = hoursWorked;
        }

        double calculateSalary() {
            return hourlyRate * hoursWorked; // Hourly rate calculation
        }

        public void payTax() {
            System.out.println(name + " pays tax on a salary of " + calculateSalary());
        }
    }

